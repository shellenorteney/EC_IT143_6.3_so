-- EC_IT143_6.3_fwt_s2_so.sql
-- This script documents the journey to finding the answer to tracking the last modification date.

-- Current understanding:
-- We need to create a trigger that updates the LastModifiedDate column whenever a record is updated.

-- Next step:
-- Create the after-update trigger to update the LastModifiedDate.
